function Output=DataFormat2str4Disp(Input,decdigits,ZeroEn)
%decdigits--������ʾ��С����λ��
%ZeroEn--�����Ƿ���Ҫ��0
    if decdigits<0
        Output=num2str(Input);
        return;
    elseif decdigits==0
        IntergerX10=floor(Input*10+5);
        Output=num2str(floor(IntergerX10/10));
        return;
    else
        Interger=floor(Input);
        if ZeroEn==1
           Decimal_Init=Input-Interger+1/(power(10,(decdigits+2)));
           Decimal_Tmp=vpa(Decimal_Init,decdigits+2);
           Interger_str=num2str(Interger);
           Decimal_str=char(Decimal_Tmp);
           Decimal_str_size=size(Decimal_str);
           Decimal_str_final=Decimal_str(2:(Decimal_str_size(1,2)-2));
           Output=strcat(Interger_str,Decimal_str_final);
        else
           Decimal_Init=Input-Interger;
           Decimal_Tmp=vpa(Decimal_Init,decdigits);
           Interger_str=num2str(Interger);
           Decimal_str=char(Decimal_Tmp);
           Decimal_str_size=size(Decimal_str);
           Decimal_str_final=Decimal_str(2:Decimal_str_size(1,2));
           Output=strcat(Interger_str,Decimal_str_final);
        end
        return;
    end

end
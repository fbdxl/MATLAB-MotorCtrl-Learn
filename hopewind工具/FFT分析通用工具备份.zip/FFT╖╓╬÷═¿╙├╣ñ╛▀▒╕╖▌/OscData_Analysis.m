function varargout = OscData_Analysis(varargin)
% OSCDATA_ANALYSIS MATLAB code for OscData_Analysis.fig
%      OSCDATA_ANALYSIS, by itself, creates a new OSCDATA_ANALYSIS or raises the existing
%      singleton*.
%
%      H = OSCDATA_ANALYSIS returns the handle to a new OSCDATA_ANALYSIS or the handle to
%      the existing singleton*.
%
%      OSCDATA_ANALYSIS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in OSCDATA_ANALYSIS.M with the given input arguments.
%
%      OSCDATA_ANALYSIS('Property','Value',...) creates a new OSCDATA_ANALYSIS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before OscData_Analysis_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to OscData_Analysis_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help OscData_Analysis

% Last Modified by GUIDE v2.5 06-Jan-2018 14:52:04

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @OscData_Analysis_OpeningFcn, ...
                   'gui_OutputFcn',  @OscData_Analysis_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before OscData_Analysis is made visible.
function OscData_Analysis_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to OscData_Analysis (see VARARGIN)

% Choose default command line output for OscData_Analysis
handles.output = hObject;
global DataInput;
global DataFFT;
global FFT1chn_Sel FFT2chn_Sel
global ListboxIDBak;
global DataSaveName;
global DataSaveNameChangeFlag;
global DataSaveNameFlag;
ListboxIDBak =0;
DataSaveNameFlag =0;
DataSaveName = {'ScopeData','FFT1Data','FFT2Data'};
DataSaveNameChangeFlag = [0 0 0];
% FFT1chn_Sel=1; FFT2chn_Sel=1;
path = cd;
FileType=Update_Listbox_Info(handles,path);
ReadOutput=Read_Listbox_Path(handles,path,FileType);
set(handles.text_ImportFileName,'string',ReadOutput.path); 
set(handles.uipanel_FFTAnalysis,'visible','off');
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes OscData_Analysis wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = OscData_Analysis_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in listbox_FFT1Disp.
function listbox_FFT1Disp_Callback(hObject, eventdata, handles)
% hObject    handle to listbox_FFT1Disp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox_FFT1Disp contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox_FFT1Disp


% --- Executes during object creation, after setting all properties.
function listbox_FFT1Disp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox_FFT1Disp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox_FFT2Disp.
function listbox_FFT2Disp_Callback(hObject, eventdata, handles)
% hObject    handle to listbox_FFT2Disp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox_FFT2Disp contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox_FFT2Disp


% --- Executes during object creation, after setting all properties.
function listbox_FFT2Disp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox_FFT2Disp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_Chn_Callback(hObject, eventdata, handles)
% hObject    handle to edit_Chn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_Chn as text
%        str2double(get(hObject,'String')) returns contents of edit_Chn as a double


% --- Executes during object creation, after setting all properties.
function edit_Chn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_Chn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_StartTime_Callback(hObject, eventdata, handles)
% hObject    handle to edit_StartTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_StartTime as text
%        str2double(get(hObject,'String')) returns contents of edit_StartTime as a double


% --- Executes during object creation, after setting all properties.
function edit_StartTime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_StartTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_Cycles_Callback(hObject, eventdata, handles)
% hObject    handle to edit_Cycles (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_Cycles as text
%        str2double(get(hObject,'String')) returns contents of edit_Cycles as a double


% --- Executes during object creation, after setting all properties.
function edit_Cycles_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_Cycles (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_BaseFreq_Callback(hObject, eventdata, handles)
% hObject    handle to edit_BaseFreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_BaseFreq as text
%        str2double(get(hObject,'String')) returns contents of edit_BaseFreq as a double


% --- Executes during object creation, after setting all properties.
function edit_BaseFreq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_BaseFreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_MaxFreq_Callback(hObject, eventdata, handles)
% hObject    handle to edit_MaxFreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_MaxFreq as text
%        str2double(get(hObject,'String')) returns contents of edit_MaxFreq as a double


% --- Executes during object creation, after setting all properties.
function edit_MaxFreq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_MaxFreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu_DisplayStyle.
function popupmenu_DisplayStyle_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_DisplayStyle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_DisplayStyle contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_DisplayStyle


% --- Executes during object creation, after setting all properties.
function popupmenu_DisplayStyle_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_DisplayStyle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu_freqAxis.
function popupmenu_freqAxis_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_freqAxis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_freqAxis contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_freqAxis


% --- Executes during object creation, after setting all properties.
function popupmenu_freqAxis_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_freqAxis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu_FFT1.
function popupmenu_FFT1_Callback(hObject, eventdata, handles)
global FFT1chn_Sel
FFT1_Sel=get(hObject,'value');
 switch FFT1_Sel
    case 1
        FFT1chn_Sel=1;            %ͨ��1
    case 2
        FFT1chn_Sel=2;            %ͨ��2
    case 3
        FFT1chn_Sel=3;            %ͨ��3
    case 4
        FFT1chn_Sel=4;           %ͨ��4       
end

% --- Executes during object creation, after setting all properties.
function popupmenu_FFT1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_FFT1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu_FFT2.
function popupmenu_FFT2_Callback(hObject, eventdata, handles)
global FFT2chn_Sel
FFT2_Sel=get(hObject,'value');
 switch FFT2_Sel
    case 1
        FFT2chn_Sel=1;            %ͨ��1
    case 2
        FFT2chn_Sel=2;            %ͨ��2
    case 3
        FFT2chn_Sel=3;            %ͨ��3
    case 4
        FFT2chn_Sel=4;           %ͨ��4      
end


% --- Executes during object creation, after setting all properties.
function popupmenu_FFT2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_FFT2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in checkbox_FFTView.
function checkbox_FFTView_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_FFTView (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_FFTView

function edit_DataPath_Callback(hObject, eventdata, handles)
% hObject    handle to edit_DataPath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_DataPath as text
%        str2double(get(hObject,'String')) returns contents of edit_DataPath as a double


% --- Executes during object creation, after setting all properties.
function edit_DataPath_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_DataPath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu_DataSrc.
function popupmenu_DataSrc_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_DataSrc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_DataSrc contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_DataSrc


% --- Executes during object creation, after setting all properties.
function popupmenu_DataSrc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_DataSrc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%% ��·���µ��ļ��б�����ˢ�£�ˢ�º�ָ����Զ�ָ���һ���ļ�(��)========
function togglebutton_Refresh_Callback(hObject, eventdata, handles)
path=get(handles.edit_DataPath,'string');
FileType=Update_Listbox_Info(handles,path);%ˢ������·�����ļ�
%Update_Listbox_InfoΪ���ù����ڲ����ú������������������ʵ�ֺ���------------
ReadOutput=Read_Listbox_Path(handles,path,FileType);%��ȡListbox�б���ĵ�ǰ·����
%Read_Listbox_PathΪ���ù����ڲ����ú������������������ʵ�ֺ���-------------
set(handles.text_ImportFileName,'string',ReadOutput.path);
%% ��Ѱ�ļ�ʱ��Ӧ·������============================================
function togglebutton_Browser_Callback(hObject, eventdata, handles)
path=get(handles.edit_DataPath,'string');
folder_name=uigetdir(path,'�Ի�������');
if(folder_name~=0)
   FileType=Update_Listbox_Info(handles,folder_name);%���ʱˢ������·�����ļ�
   %Update_Listbox_InfoΪ���ù����ڲ����ú������������������ʵ�ֺ���------------
   path_Init=get(handles.edit_DataPath,'string');
   ReadOutput=Read_Listbox_Path(handles,path_Init,FileType);%��ȡListbox�б���ĵ�ǰ·����
   %Read_Listbox_PathΪ���ù����ڲ����ú������������������ʵ�ֺ���-------------
   set(handles.text_ImportFileName,'string',ReadOutput.path);
else
    %��ֹ��㿪·����ȴ���κβ�������MATLAB����
end


%% ������һĿ¼====================================================
function togglebutton_Return_Callback(hObject, eventdata, handles)
path_Init=get(handles.edit_DataPath,'string');
N_string=size(path_Init); %��ǰ·����Ӧ���ַ���
if N_string(1,2)<3
    return;
else
    Cnt=N_string(1,2);
    for i=1:N_string(1,2)
        if path_Init(N_string(1,1),Cnt)=='\'
            Numb=Cnt;
        else
            Cnt=Cnt-1;
        end
    end
end

if Numb==3
    path_end=path_Init(N_string(1,1),1:Numb); 
elseif Numb>3
    path_end=path_Init(N_string(1,1),1:(Numb-1)) ;
else
    return;
end
set(handles.edit_DataPath,'string',path_end);
FileType=Update_Listbox_Info(handles,path_end);%���ʱˢ������·�����ļ�
ReadOutput=Read_Listbox_Path(handles,path_end,FileType);%��ȡListbox�б������һĿ¼·����
set(handles.text_ImportFileName,'string',ReadOutput.path);
% Hint: get(hObject,'Value') returns toggle state of togglebutton_Return


%% ·�����ļ����У��б�=============================================
function listbox_File_Callback(hObject, eventdata, handles)
global ListboxIDbak
path_Init=get(handles.edit_DataPath,'string');
ReadOutput=Read_Listbox_Path(handles,path_Init,0);%FileType=0��ǰ��ַ��Ч
if ReadOutput.ID==ListboxIDbak;
   FileType=Update_Listbox_Info(handles,ReadOutput.path); %%˫����ʾ���ļ�������������һ�˵�
else
   ListboxIDbak=ReadOutput.ID;
   FileType=0;
end
path_Init=get(handles.edit_DataPath,'string');
ReadOutput=Read_Listbox_Path(handles,path_Init,FileType);%
set(handles.text_ImportFileName,'string',ReadOutput.path);
% Hints: contents = cellstr(get(hObject,'String')) returns listbox_File contents as cell array
% contents{get(hObject,'Value')} returns selected item from listbox_File

% --- Executes during object creation, after setting all properties.
function listbox_File_CreateFcn(hObject, eventdata, handles)

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% ===�ڲ����ú���=================================================
%���·��������б�����ı�����------------------------------------------------
function FileType=Update_Listbox_Info(handles,path)
% Info��һ���ṹ�壬�ṹ����һ������ı�����ʽΪ[name date bytes isdir datenum];
% name--Filename; date--modification date;
%bytes--number of bytes allocated to the file
%isdir--1 if name is directory and 0 if not
%datenum--modification date as a matlab serial number
    if path==0
        return;
    else
        Src=dir(path);
        [row Line]=size(Src);
        if row==0 %��ǰ��ַ��Ч
            msgbox('��ǰ��ַ��Ч','Error','error')
            FileType=0;
            set(handles.edit_DataPath,'string','');
            set(handles.listbox_File,'string','');
        elseif row==1 %��ǰ·��Ϊ�ļ��������ļ���
             FileType=1;
        elseif row==2 %��ǰ·��Ϊ���ļ���
             FileType=2;
             set(handles.edit_DataPath,'string',path);
             set(handles.listbox_File,'string','');
        else%��ǰ·���ļ��������ļ�
             FileType=3;
             set(handles.edit_DataPath,'string',path);
             set(handles.listbox_File,'string','');
             path_size=size(path);
             if path_size(1,2)==3%��ʾ·��Ϊ�̷�������C:\��
                Info=Src; 
             else
                Info=Src(3:row,1);  
             end
              [row Line]=size(Info);
              InfoNew=Info;
              
              %%��Ŀ¼�µ��ļ������ļ���ǰ���ļ����ں�-----
              Numb=1;
              for i=1:row*2
                  if rem(i,row)==0
                      n=row;
                  else
                      n=rem(i,row);
                  end
                  
                  if  (i<=row)&&(Info(n,1).isdir==1)  
                      InfoNew(Numb)=Info(n,1);
                      Numb=Numb+1;
                  elseif (i>row)&&(Info(n,1).isdir==0) 
                      InfoNew(Numb)=Info(n,1);
                      Numb=Numb+1;
                  else
                      %%��ִ���κβ���
                  end
              end
             %��lsitbox��������ʾ�ļ���-------------------------------------
             FileName= InfoNew(1).name;
             for i=2:row
                 FileName=char({FileName,InfoNew(i).name});
             end
             set(handles.listbox_File,'string',FileName);
             set(handles.listbox_File,'value',1);
        end     
    end
%% ===�ڲ����ú���=================================================
%��ȡ���������б���ĵ�ǰ·����----------------------------------------------
function ReadOutput=Read_Listbox_Path(handles,path_Init,FileType);
str=get(handles.listbox_File,'string');
listboxID=get(handles.listbox_File,'value');
if FileType==2%��ǰ·��Ϊ���ļ���
    ReadOutput.path=path_Init;
else
    listboxID_Name=str(listboxID,:);
    %listboxID��ʾ�б��е�ID��
    %':'��ʾ�б��е������ַ���(���Ϊ1���ʾ��1���ַ�)
    path_Init_size=size(path_Init);
    if path_Init_size(1,2)==0
        ReadOutput.path='';
    else
        if path_Init(path_Init_size(1,1),path_Init_size(1,2))=='\'
            ReadOutput.path=strcat(path_Init,listboxID_Name);
        else
            ReadOutput.path=strcat(path_Init,'\',listboxID_Name);
        end
    end
    ReadOutput.ID=listboxID;
end

%% �������ݻ�ȡ;���ͷ�ʽ��������Ϣ==========================
function togglebutton_DataRead_Callback(hObject, eventdata, handles)
global DataInput 
%��ȡ����ʱ,������FFT���������ť����----------------------------------------
set(handles.togglebutton_FFTSave,'visible','off');
OscSrcType=get(handles.popupmenu_DataSrc,'value');
path_Init=get(handles.text_ImportFileName,'string');

%�����ⲿ���������ݽ��з������ٽ���������-----------------------------------
DataInput=DataInfoAnalysisFunc(path_Init,OscSrcType);
set(handles.text_ChannelNumber,'string',DataInput.ChnNumb);

if DataInput.ChnNumb>0  %%�����ݲŽ���
   set(handles.text_SamplePoints,'string',DataInput.SamplePoints);
   
   %�ַ�ƴ�ӣ�����DataInput.SampleLength=0.1������ʾ����ʱ�䳤��Ϊ0.1s
   Sample.Length=strcat(num2str(DataInput.SampleLength),'s');
   set(handles.text_SampleLength,'string',Sample.Length);
   set(handles.text_FFTDataFlag,'string',DataInput.iFlag4FFTDataAvail);
   plot(handles.axes_osc,DataInput.time,DataInput.data);%%��ԭ���ݶ�Ӧ�Ĳ���
   set(handles.axes_osc,'XGrid','on','YGrid','on');
   
   %�����ݻ�����Ϣ����󣬴�FFT�������
   set(handles.uipanel_FFTAnalysis,'visible','on');
   
   %����ͨ����ʾ��Ĭ��ȫ����ʾ
   set(handles.edit_Chn,'string','');%�����㣬�Է�����
   FileName='1';%%��������ݣ����ٻ���1��ͨ��
   
   if DataInput.ChnNumb>=2  %%Ŀǰ�õ�ʾ���������4��ͨ��
      for i=2:DataInput.ChnNumb
          FileName=strcat(FileName,',');%��'1,'
          FileName=strcat(FileName,num2str(i));%��2
      end
   else
       %���κβ���
   end
   set(handles.edit_Chn,'string',FileName);%����ͨ����ֵ,��1,2,3,4
   
   if DataInput.iFlag4FFTDataAvail==0 %���ݷ����������FFT�������
      set(handles.checkbox_OriFFTDataDisp,'visible','off');
   else
      set(handles.checkbox_OriFFTDataDisp,'visible','on'); 
   end
   %�����ݽ��з���ʱ,FFTͨ��ѡ���ʼ��---------------------------------------
   set(handles.popupmenu_FFT1,'string','');
   set(handles.popupmenu_FFT2,'string','');
   
   FFTchnName='chn1';
   if DataInput.ChnNumb>=2
      for i=2:DataInput.ChnNumb
          Name=strcat('chn',num2str(i));
          FFTchnName=char({FFTchnName,Name});
      end
   end
   set(handles.popupmenu_FFT1,'string',FFTchnName);
   set(handles.popupmenu_FFT2,'string',FFTchnName);
else %%���ļ��������ݣ��ر�FFT�������
    set(handles.uipanel_FFTAnalysis,'visible','off');
end

%% FFT���������ʾ��ʽ==============================================
function togglebutton_FFTDisp_Callback(hObject, eventdata, handles)
global DataInput DataFFT
global FFT1chn_Sel FFT2chn_Sel
%�ȸ���FFT�������������ʾ������水ť---------------------------------------
set(handles.togglebutton_FFTSave,'visible','on')

%ѡ��Ҫ�������źŶ�Ӧ��ͨ�����----------------------------------------------
str_OscChnInfo=get(handles.edit_Chn,'string');
str_size=size(str_OscChnInfo);


%plot��ͨ���鲼��������ڲ�����Ҫ����ַ�������ʾ��ʽ�����澯----------------
cnt=0;
for i=1:str_size(1,2)
    if str_OscChnInfo(i)==',';
        cnt=cnt+1;
    end
end

%ͨ������ʾ1,2,3,4��Num_Capture=1234----------------------------------------
Num_Capture=str_OscChnInfo(isstrprop(str_OscChnInfo,'digit'));
Num_Capture_size=size(num2str(Num_Capture));

if(Num_Capture_size+cnt)<str_size(1,2)%ͨ�����ڴ������ֺͶ���������ַ�
    msgbox('����ͨ����������','Error','error');
    set(handles.edit_Chn,'string','');%ͨ���б�����
    return;
end

%��ȡ'��'�ĸ���������-------------------------------------------------------
num_comma=1;
str_num(1)=1;
for i=1:str_size(1,2)
    if str_OscChnInfo(i)==',';
        num_comma=num_comma+1;
        str_num(num_comma)=i;
    elseif i==str_size(1,2)
        num_comma=num_comma+1;
        str_num(num_comma)=i;
    end
end

chn_num=1;      
if num_comma==1 %ͨ����û�ж��ţ�ֻ��ͨ��1
    chn_num=str2num(str_OscChnInfo);
else
    for i=1:num_comma-1
        chn_numTmp(i)=str2num(str_OscChnInfo(str_num(i):str_num(i+1)));
        if chn_numTmp(i)>DataInput.ChnNumb
           msgbox('����ͨ�������õ�ͨ��������ʵ��ͨ����','Error','error')
           return;
        end
    end
    chn_numTmp_sort=sort(chn_numTmp);
    chn_num(1)=chn_numTmp_sort(1);
    
    chn_cnt=1;%���ݷ�����ѡ��ͨ����
    for i=1:num_comma-1
        if chn_num(chn_cnt)~=chn_numTmp_sort(i)
            chn_cnt=chn_cnt+1;
            chn_num(chn_cnt)=chn_numTmp_sort(i);
        end
    end
end

%%ѡ��Ҫ���������ݺ��������FFT����++++++++++++++++++++++++++++++++++++++++
for i=1:chn_cnt  %����FFT��������������װ������
    data4FFTplot(:,i)=DataInput.data(:,chn_num(i));
end

Tmp=get(handles.edit_StartTime,'string');
StartTime=str2num(Tmp);
if  StartTime<=0
    StartTime=0;
end
set(handles.edit_StartTime,'string',StartTime)

Tmp=get(handles.edit_Cycles,'string');
Cycles=str2num(Tmp);
if  Cycles<=0
    Cycles=1;%���ٷ���һ����Ƶ����
else
    Cycles=floor(Cycles);
    if Cycles<=0
        Cycles=1;
    end
end
set(handles.edit_Cycles,'string',Cycles)

Tmp=get(handles.edit_BaseFreq,'string');
BaseFreq=str2double(Tmp);
Tmp=get(handles.edit_MaxFreq,'string');
MaxFreq=str2double(Tmp);
PlotByFFTSetEn=get(handles.checkbox_FFTView,'value');
OriFFTDataShown=get(handles.checkbox_OriFFTDataDisp,'value');

%���ݳ��ȼ���+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
TimeSumSet=StartTime+Cycles/BaseFreq;
if TimeSumSet>DataInput.SamplePoints
    msgbox('��ѡ���ݳ��ȳ���','Error','error')
    return;
else
    %����FFT������ʼ��
    SampleStep=DataInput.time(1,2)-DataInput.time(1,1);
    StartPosition=floor(StartTime/SampleStep)+1;
    EndPosition=floor(TimeSumSet/SampleStep)+1;
    TimeLength=EndPosition-StartPosition+1;
    
    for i=1:TimeLength
        data_FFT(i,1:chn_cnt)=data4FFTplot(StartPosition+i-1,1:chn_cnt);
        time_FFT(i)=DataInput.time(StartPosition+i-1);
    end
end

%%��ͼ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
if OriFFTDataShown==1
    plot(handles.axes_osc,DataInput.FFTData(:,1),DataInput.FFTData(:,2));
    set(handles.axes_osc,'XGrid','on','YGrid','on');
elseif PlotByFFTSetEn==0
    plot(handles.axes_osc,DataInput.time,data4FFTplot);
    set(handles.axes_osc,'XGrid','on','YGrid','on');
else
    plot(handles.axes_osc,time_FFT,data_FFT);
    set(handles.axes_osc,'XGrid','on','YGrid','on','Xlim',[StartTime,TimeSumSet]);
end

%%FFT��������+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

if FFT1chn_Sel>num_comma-1
    msgbox('FFT1��ѡͨ����������֮��','Error','error')
    return;
else
    FFT1_Chn=get(handles.popupmenu_FFT1,'value');
end

if FFT2chn_Sel>num_comma-1
    msgbox('FFT1��ѡͨ����������֮��','Error','error')
    return;
else 
    FFT2_Chn=get(handles.popupmenu_FFT2,'value');
end    
DispStyle=get(handles.popupmenu_DisplayStyle,'value');
Freqaxis4FFT=get(handles.popupmenu_freqAxis,'value');

%%ѡȡ�������͵��ⲿ��FFT�������ٵ��ؽ��--------------------------------------
FFT1Data_Output=FFTAnalysis(data_FFT(:,FFT1_Chn),TimeLength,SampleStep,BaseFreq,...
                            MaxFreq,Cycles);
FFT2Data_Output=FFTAnalysis(data_FFT(:,FFT2_Chn),TimeLength,SampleStep,BaseFreq,...
                            MaxFreq,Cycles);
DataFFT.FFT1 = FFT1Data_Output;
DataFFT.FFT2 = FFT2Data_Output;   
if DispStyle==1 %Ĭ������״ͼ��ʾFFT�������
   set(handles.listbox_FFT1Disp,'visible','off');
   set(handles.listbox_FFT2Disp,'visible','off');
   set(handles.axes_FFT1,'visible','on');
   set(handles.axes_FFT2,'visible','on');
   
   Xaxis=sort(FFT1Data_Output.Freq);
   Xaxis_size=size(Xaxis);
   Yaxis=sort(FFT1Data_Output.Percent);
   Yaxis_size=size(Yaxis);
   KYaxisShown=1.5;

   if Freqaxis4FFT==2 %г���Դ�����ʾ
      bar(handles.axes_FFT1,FFT1Data_Output.Freq/BaseFreq,FFT1Data_Output.Percent,0.2);
      set(handles.axes_FFT1,'Xlim',[0,Xaxis(Xaxis_size(1,2))/BaseFreq+1],...
          'Ylim',[0,round(FFT1Data_Output.Percentmax*KYaxisShown)]);
      axes(handles.axes_FFT1);
      xlabel('Harmonic Order');ylabel('Mag(%of Fundamental)');
      title(handles.axes_FFT1,['Fundamental(',num2str(BaseFreq),')=',...
          num2str(FFT1Data_Output.FundamentalPeak),' ,THD=',...
          num2str(FFT1Data_Output.THD),'%'],'Fontsize',10,'color','r');
   else
      bar(handles.axes_FFT1,FFT1Data_Output.Freq,FFT1Data_Output.Percent,0.2);
      set(handles.axes_FFT1,'Xlim',[0,Xaxis(Xaxis_size(1,2))+BaseFreq],...
          'Ylim',[0,round(FFT1Data_Output.Percentmax*KYaxisShown)]);
      axes(handles.axes_FFT1);
      xlabel('Frequency(Hz)');ylabel('Mag(%of Fundamental)');
      title(handles.axes_FFT1,['Fundamental(',num2str(BaseFreq),')=',...
          num2str(FFT1Data_Output.FundamentalPeak),' ,THD=',...
          num2str(FFT1Data_Output.THD),'%'],'Fontsize',10,'color','r');
   end
   
   Xaxis=sort(FFT2Data_Output.Freq);
   Xaxis_size=size(Xaxis);
   Yaxis=sort(FFT2Data_Output.Percent);
   Yaxis_size=size(Yaxis);
   KYaxisShown=1.5;
    
   if Freqaxis4FFT==2 %г���Դ�����ʾ
      bar(handles.axes_FFT2,FFT2Data_Output.Freq/BaseFreq,FFT2Data_Output.Percent,0.2);
      set(handles.axes_FFT2,'Xlim',[0,Xaxis(Xaxis_size(1,2))/BaseFreq+1],...
          'Ylim',[0,round(FFT2Data_Output.Percentmax*KYaxisShown)]);
      axes(handles.axes_FFT2);
      xlabel('Harmonic Order');ylabel('Mag(%of Fundamental)');
      title(handles.axes_FFT2,['Fundamental(',num2str(BaseFreq),')=',...
          num2str(FFT2Data_Output.FundamentalPeak),' ,THD=',...
          num2str(FFT2Data_Output.THD),'%'],'Fontsize',10,'color','r');
   else
      bar(handles.axes_FFT2,FFT2Data_Output.Freq,FFT2Data_Output.Percent,0.2);
      set(handles.axes_FFT2,'Xlim',[0,Xaxis(Xaxis_size(1,2))+BaseFreq],...
          'Ylim',[0,round(FFT2Data_Output.Percentmax*KYaxisShown)]);
      axes(handles.axes_FFT2);
      xlabel('Frequency(Hz)');ylabel('Mag(%of Fundamental)');
      title(handles.axes_FFT2,['Fundamental(',num2str(BaseFreq),')=',...
          num2str(FFT2Data_Output.FundamentalPeak),' ,THD=',...
          num2str(FFT2Data_Output.THD),'%'],'Fontsize',10,'color','r');
   end
   
elseif DispStyle==2 %�б���ʾ����г�������ٷֱ�
     axes(handles.axes_FFT1); 
     cla reset
     axes(handles.axes_FFT2); 
     cla reset
     set(handles.axes_FFT1,'visible','off');
     set(handles.axes_FFT2,'visible','off');
     set(handles.listbox_FFT1Disp,'visible','on');
     set(handles.listbox_FFT2Disp,'visible','on');

     FFTListDisp1=Listbox_Info(FFT1Data_Output)
     FFTListDisp2=Listbox_Info(FFT2Data_Output);
     
     %����lsitbox�ڲ�������������ϻ�澯����ʧ
     set(handles.listbox_FFT1Disp,'string',FFTListDisp1);
     set(handles.listbox_FFT1Disp,'value',1);
     set(handles.listbox_FFT2Disp,'string',FFTListDisp2);
     set(handles.listbox_FFT2Disp,'value',1);
else
    %%���κβ���
end


%% FFT����������淽ʽ==============================================
function togglebutton_FFTSave_Callback(hObject, eventdata, handles)
global DataInput DataFFT  
global DataSaveName DataSaveNameFlag DataSaveNameChangeFlag
[sel,ok]=listdlg('liststring',{'All Chn Data','FFT1 Data','FFT2 Data'},...
    'listsize',[180,80],'okString','ȷ��','CancelString','ȡ��','promptstring',...
    'select the data you want to save','name','Save configure','selectionmode','multiple');

%��ȡ��ѡ�е��ļ���---------------------------------------------------------
path_Text=get(handles.text_ImportFileName,'string');
path_Text_size=size(path_Text);
cnt=path_Text_size(1,2);
iFlag=0;
 for i=1:path_Text_size(1,2)
     if path_Text(path_Text_size(1,1),cnt)=='.'
         Numb_end=cnt-1;
     elseif path_Text(path_Text_size(1,1),cnt)=='\'
         if iFlag==0
             Numb_start=cnt+1;
             iFlag=1;
         end
     else
         %
     end
     cnt=cnt-1;
 end
Filename_Init=path_Text(path_Text_size(1,1),Numb_start:Numb_end);
Filename_Init=strcat(Filename_Init,'FFTData');
FFT1sel=get(handles.popupmenu_FFT1,'value');
FFT1name_Init=strcat('chn',num2str(FFT1sel),'fft');
FFT2sel=get(handles.popupmenu_FFT2,'value');
FFT2name_Init=strcat('chn',num2str(FFT2sel),'fft');

Nametitle_Init={'please input all the chn data name:',...
    'please input FFT1 data name:','please input FFT2 data name:'};
Namefile_Init={Filename_Init,FFT1name_Init,FFT2name_Init};
if ok==0
    return;
else
    sel_size=size(sel);
    for i=1:sel_size(1,2)
        Nametitle(i)=Nametitle_Init(sel(i));
        if DataSaveNameFlag==1
            if DataSaveNameChangeFlag(sel(i))==1
               Namefile(i)=DataSaveName(sel(i)); 
            else
               Namefile(i)=Namefile_Init(sel(i));
            end
        else
            Namefile(i)=Namefile_Init(sel(i));
        end
    end
end

answer=inputdlg(Nametitle,'File save name set',1,Namefile);
DataSaveNameFlag=1;
for i=1:sel_size(1,2)
    DataSaveName(sel(i))=answer(i);
    DataSaveNameChangeFlag(sel(i))=1;
end
Src=dir;
[row Line]=size(Src);
iFilePathExsitFlag=0;

for i=1:row
    name_size=size(Src(i).name);
    if name_size(1,2)==8
       if  Src(i).name=='DataSave'%����FFT����������ļ�������
           iFilePathExsitFlag=1;
       end
    end
end

%���û�����ȴ��������ļ���·�����˴����������������ļ����ᱣ����ǰһ��������·����
if iFilePathExsitFlag==0  
    dirname='DataSave';
    a=['mkdir ' dirname];
    system(a);
end

for i=1:sel_size(1,2)
    if sel(i)==1         %�������з������
       DataSave(:,1)=DataInput.time;
       DataSave(:,2:(DataInput.ChnNumb+1))=DataInput.data;
       savePath=char(strcat('./DataSave/',answer(i),'.mat'));
       save(savePath,'DataSave');
    elseif sel(i)==2     %����FFT1�������
       FFTData=DataFFT.FFT1; 
       savePath=char(strcat('./DataSave/',answer(i),'.mat'));
       save(savePath,'FFTData');
    elseif sel(i)==3     %����FFT1�������
       FFTData=DataFFT.FFT2; 
       savePath=char(strcat('./DataSave/',answer(i),'.mat'));
       save(savePath,'FFTData');
    else
        %���κβ���
    end
end
% Hint: get(hObject,'Value') returns toggle state of togglebutton_FFTSave
%% �ڲ����ú���====================================================
%�б�����ʾFFT�ķ����������-------------------------------------------------
function output=Listbox_Info(FFTData)
%�ַ���ʾ
% a= 'Sample time       =';
% b= ' s';
% c= 'SamplesPerCycle   =';
% d= 'DC Component      =';
% e= 'Fundamental       =';
% f= ' Peak (';
% g= ' rms)';
% h= 'Total Harmonic Distortion (THD)=';
% m= '%';
 %�ַ���ʾ
a= 'Sampling time     = ';
b= ' s';
c= 'Samples per cycle = ';
d= 'DC component      = ';
e= 'Fundamental       = ';
f= ' peak (';
g= ' rms)';
h= 'Total Harmonic Distortion (THD) = ';
m= '%';
%��һ���ַ���ʾ
n=size(a);na=n(1,2);
n=size(b);nb=n(1,2);
data=num2str(FFTData.Sampletime);
n=size(data);n_input=n(1,2);
for i=1:(na+nb+n_input)
   if i<= na
       str_lin1(i)=a(i);
   elseif i<=na+n_input
       str_lin1(i)=data(i-na);
   else
       str_lin1(i)=b(i-na-n_input);
   end
end

%�ڶ����ַ���ʾ
n=size(c);nc=n(1,2);
data=num2str(FFTData.SamplePerCycle);
n=size(data);n_input=n(1,2);
for i=1:(nc+n_input)
   if i<= nc
       str_lin2(i)=c(i);
   else
       str_lin2(i)=data(i-nc);
   end
end

%�������ַ���ʾ
n=size(d);nd=n(1,2);
data=num2str(FFTData.DCComponent);
n=size(data);n_input=n(1,2);
for i=1:(nd+n_input)
   if i<= nd
       str_lin3(i)=d(i);
   else
       str_lin3(i)=data(i-nd);
   end
end

%�������ַ���ʾ
n=size(e);ne=n(1,2);
data=num2str(FFTData.FundamentalPeak);
n=size(data);n_input=n(1,2);
n=size(f);nf=n(1,2);
data1=num2str(FFTData.FundamentalPeak/sqrt(2));
n=size(data1);n1_input=n(1,2);
n=size(g);ng=n(1,2);

for i=1:(ne+n_input+nf+n1_input+ng)
   if i<= ne
       str_lin4(i)=e(i);
   elseif i<= ne+n_input
       str_lin4(i)=data(i-ne);
   elseif i<=ne+n_input+nf
       str_lin4(i)=f(i-ne-n_input);
   elseif i<=ne+n_input+nf+n1_input
       str_lin4(i)=data1(i-ne-n_input-nf);
   else
       str_lin4(i)=g(i-ne-n_input-nf-n1_input);
   end
end
%�����п���
str_line_empty='    ';
%�������ַ���ʾ
n=size(h);nh=n(1,2);
n=size(m);nm=n(1,2);
data=num2str(FFTData.THD);
n=size(data);n_input=n(1,2);
for i=1:(nh+nm+n_input)
   if i<= nh
       str_lin6(i)=h(i);
   elseif i<=(nh+n_input)
       str_lin6(i)=data(i-nh);
   else
       str_lin6(i)=m(i-nh-n_input);
   end
end

output(1:7)={str_lin1,str_lin2,str_lin3,str_lin4,str_line_empty,str_lin6,str_line_empty};

data_size=size(FFTData.Freq);
for i=1:data_size(1,2)
    ListFlag =0;
    if rem(FFTData.Freq(i),FFTData.FundFreq)==0
        str_h = '  (DC) :';
        ListFlag =1;
    elseif rem(FFTData.Freq(i),FFTData.Cycles)==1%��������ͬ������Χ�ڵ�һ�����ȥ
        HarmonicOrder=floor(i/FFTData.Cycles);
        if HarmonicOrder==1
            str_h = '  (Fnd) :';
            ListFlag =2;
        else
            str_h = strcat('(h',num2str(HarmonicOrder),') :');
            ListFlag =3;
        end
    else
        str_h=' ';
        ListFlag =4;
    end

    FreqTmp=(i-1)*(FFTData.FundFreq/FFTData.Cycles);
    %%�����ⲿ����
    tmp=DataFormat2str4Disp(FreqTmp,4,0);
    Freq_str=num2str(tmp);
    Freq_str_size=size(Freq_str);
    Numb=Freq_str_size(1,2);
    HzAxis=20;
    str_lineDisp((HzAxis-1):HzAxis)='  ';
    str_lineDisp(HzAxis-2)='z';
    str_lineDisp(HzAxis-3)='H';
    str_lineDisp(HzAxis-4)=' ';
    HzcntSet=HzAxis-5;
    for j=1:HzcntSet
        if Numb>0
            str_lineDisp(HzcntSet-j+1)=Freq_str(Numb);
            %str_LineDisp(HzcntSet-j+1) = Freq_str(Numb);
            Numb=Numb-1;
        else
            str_lineDisp(HzcntSet-j+1)=' ';
        end
    end
    str_h_size=size(str_h);
    str_lineDisp((HzAxis+1):(HzAxis+str_h_size(1,2)))=str_h;
    %%г���ٷֱ���ʾ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    percent_str=DataFormat2str4Disp(FFTData.Percent(i),2,1);
    percent_str_size=size(percent_str);
    Numb=percent_str_size(1,2);
    PercentAxis=50;
    CountSet=PercentAxis-(HzAxis+str_h_size(1,2));
    for j=1:CountSet
        if Numb>0
            str_lineDisp(PercentAxis-j+1)=percent_str(Numb);
            Numb=Numb-1;
        else
            str_lineDisp(PercentAxis-j+1)=' ';
        end
    end
     str_lineDisp(PercentAxis+1)='%';
    
     %%г���Ƕ���ʾ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    angle_str=DataFormat2str4Disp(FFTData.angle(i),1,1);
    angle_str_size=size(angle_str);
    Numb=angle_str_size(1,2);
    AngleAxis=70;
    CountSet=AngleAxis-PercentAxis-1;
    for j=1:CountSet
        if Numb>0
            str_lineDisp(AngleAxis-j+1)=angle_str(Numb);
            Numb=Numb-1;
        else
            str_lineDisp(AngleAxis-j+1)=' ';
        end
    end
     str_lineDisp(AngleAxis+1)='��';
     output(7+i)={str_lineDisp};
end

% --- Executes on button press in checkbox_OriFFTDataDisp.
function checkbox_OriFFTDataDisp_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_OriFFTDataDisp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_OriFFTDataDisp
